import React from "react";
import { cn } from "../../lib/utils";

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}

export const Card: React.FC<CardProps> = ({ 
  children, 
  className,
  hover = false,
  ...props 
}) => {
  return (
    <div 
      className={cn(
        "kit-card", 
        hover && "transition-all duration-300 hover:translate-y-[-4px] hover:shadow-lg", 
        className
      )} 
      {...props}
    >
      {children}
    </div>
  );
};
